var moment = require('moment');
var fs = require('fs');
var content = fs.readFileSync('testData.json');
var contentJson = JSON.parse(content);

var data1 = [{
        date: '2019-01-01',
        sales: 30
        },
        {
        date: '2019-01-02',
        sales: 40
        },
        {
        date: '2019-01-10',
        sales: 50
        },
        {
        date: '2019-01-20',
        sales: 60
        }
    ]
var weekwise = []
var monthwise = []
//console.log(week);
data1.forEach((rec) => {
    weekno = moment(rec.date).week();
    year = moment(rec.date).year();
    month = moment(rec.data, 'YYYY-MM-DD').month();
    day = moment(rec.data, 'YYYY-MM-DD').day();
    console.log('year : ' + year + ' :mnt : ' + month + ' : week : ' + day);
    // weeknostr = 'Week'+weekno;
    // var dateTemp = {week: '', sales: 0}
    // dateTemp.week = 'Week'+weekno;
    // dateTemp.week = 'Week'+weekno;
    // dateTemp.sales = rec.sales;
    // var existingweek = false;
    // weekwise.forEach((w) => {
    //     if (w.week == weeknostr) {
    //         w.sales += rec.sales;
    //         existingweek = true;
    //     }
    // });
    // if (!existingweek) {
    //     weekwise.push(dateTemp);
    // }
});

console.log(weekwise);

//var data1 = [{
    //     date: '2019-01-01',
    //     sales: 30
    //     },
    //     {
    //     date: '2019-01-02',
    //     sales: 40
    //     },
    //     {
    //     date: '2019-01-10',
    //     sales: 50
    //     },
    //     {
    //     date: '2019-01-20',
    //     sales: 60
    //     }
    // ]